﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KlevelBrowser.View
{
    public partial class viewHistory : Form
    {
        public viewHistory()
        {
            InitializeComponent();
        }

        public RichTextBox getRichTextB()
        {
            return this.richTextBox1;
        }

        public void HideRichTextBox()
        {
            richTextBox1.Hide();
        }

        public void LinkLab()

        {

            LinkLabel dynamicLinkLabel = new LinkLabel();
         
        }

        private void DynamicButton_Click(object sender, EventArgs e)

        {

            MessageBox.Show("Dynamic button is clicked");

        }

        private void viewHistory_Load(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

      
    }
}
