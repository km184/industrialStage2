﻿using KlevelBrowser.Controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KlevelBrowser.View
{
    public partial class ViewHTML : Form
    {
        public ViewHTML()
        {
            InitializeComponent();
        }


        public RichTextBox getrichTextbo1()
        {
            return this.richTextBox1;
        }

        public TextBox displayUrlTextbox()
        {
            return this.textBox2;
        }

        public String geturlInputFromViewPageHTML()
        {
            return textBox2.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WebBrowserController bc = new WebBrowserController(this);
            bc.updatePlusviewHisroty();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            WebBrowserController bc = new WebBrowserController(this);
            bc.deleteHistory();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            WebBrowserController bc = new WebBrowserController(this);
            bc.addtohistory();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
            WebBrowserController bc = new WebBrowserController(this);
            bc.viewFavs();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            WebBrowserController bc = new WebBrowserController(this);
            bc.NextUrl();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            WebBrowserController bc = new WebBrowserController(this);
            bc.prevUrl();
        }
    }
}
