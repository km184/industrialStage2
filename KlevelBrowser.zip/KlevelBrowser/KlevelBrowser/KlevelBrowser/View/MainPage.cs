﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using KlevelBrowser.Controller;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web.UI.WebControls;

namespace KlevelBrowser.View
{
    public partial class MainPage : Form
    {
        public MainPage()
        {
            InitializeComponent();
        }

        public void button1_Click(object sender, EventArgs e)
        {
            WebBrowserController bc = new WebBrowserController(this);
            bc.updateviewhtml();
        }


        public String geturlInput()
        {
            return textBox1.Text;
        }


    

        public void statrTimer1()
        {
            this.timer1.Start();
         
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

      
    }
}
