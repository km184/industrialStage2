﻿using System;
using System.Diagnostics;
using System.Media;
using System.Threading.Tasks;

using System.Net.Http;
using System.IO;

namespace  Model
{
    class Browser
    {
        #region variables
        Model.Favourites favouriteLinks;
      


        #endregion

        


        #region Send request
        public async Task<String> geth(string url)
        {

            String res = "";

           

            
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    using (HttpResponseMessage mes = await client?.GetAsync(url))


                    {

                       



                        using (HttpContent cont = mes.Content)
                        {
                            
                             string data = await cont.ReadAsStringAsync();
                             return res=res+data;
                            
                            
                           
                           
                            //html.getcodebox().Text = $"Status-code:{mes.StatusCode.ToString()}";
                            //html.getTextarea().Text = res;
                            //html.Text = name;
                            //watch.Stop();
                            //var elapsedtime = watch.ElapsedMilliseconds;
                            //html.getTimebox().Text = $"Time elapsed:{elapsedtime} ms";

                        }
                    }
                }
                catch (HttpRequestException e)
                {
                  
                   
                    SystemSounds.Asterisk.Play();
                }catch(InvalidOperationException IOE)
                {
                   
                }
              
                
                }


            return res;
           
        }




 #endregion


        public  string getBetween(string strSource, string strStart, string strEnd)
        {
            if (strSource.Contains(strStart) && strSource.Contains(strEnd))
            {
                int Start, End;
                Start = strSource.IndexOf(strStart, 0) + strStart.Length;
                End = strSource.IndexOf(strEnd, Start);
                return strSource.Substring(Start, End - Start);
            }

            return "";
        }

        public void writeURLToHistorfile(string link)
        {
            string HistoryFile = @"C:\Users\kumug\Documents\Visual Studio 2015\Projects\KlevelBrowser\KlevelBrowser\KlevelBrowser\DatabaseH.txt";
            StreamWriter sw = new StreamWriter(HistoryFile,true);
            

            sw.WriteLine(link);
            sw.Close();

        }

        public void clearHistory()
        {
            string path = @"C:\Users\kumug\Documents\Visual Studio 2015\Projects\KlevelBrowser\KlevelBrowser\KlevelBrowser\DatabaseH.txt";
            FileStream fileStream = File.Open(path, FileMode.Open);
            fileStream.SetLength(0);
            fileStream.Close();
        }

         public void writeURLToHistorfavouriets(string link)
        {


            string HistoryFile = @"C:\Users\kumug\Documents\Visual Studio 2015\Projects\KlevelBrowser\KlevelBrowser\KlevelBrowser\FavouritesDatabase.txt";
            StreamWriter sw = new StreamWriter(HistoryFile, true);
            sw.WriteLine(link);
            sw.Close();


        }












    }


      

}
