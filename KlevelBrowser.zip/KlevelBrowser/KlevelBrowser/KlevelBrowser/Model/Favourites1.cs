﻿using KlevelBrowser.Model;
using System;
using System.Collections;

namespace Model
{
    internal class Favourites: HistoryLinkedList

         
    {
         public string url { get; set; }
         public string name { get; set; }
          
        public Favourites(string name,string URL)
        {
            this.name = name;
            this.url = URL;
        }



        public new Hashtable readDatabase()
        {
           Hashtable data= getHistoryDatafavs();
           return data;
        }





    }
}