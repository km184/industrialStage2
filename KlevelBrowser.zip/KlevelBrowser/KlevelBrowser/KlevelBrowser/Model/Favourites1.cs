﻿using KlevelBrowser.Model;

namespace Model
{
    internal class Favourites: HistoryLinkedList

         
    {
         

    }
}