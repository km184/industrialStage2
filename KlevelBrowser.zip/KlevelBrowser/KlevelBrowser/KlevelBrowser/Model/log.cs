﻿using Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KlevelBrowser.Model
{
    class log
    {


        Hashtable tafole = new Hashtable();







        public void CreateAhistoryObject(string url1,string name)
        {
            
          //  DateTime now = DateTime.Now;
            
           

            tafole?.Add(url1, name);
        }



        public string returnContents()
        {
            //addToHistory();
            StringBuilder builder = new StringBuilder();
            foreach (DictionaryEntry item in tafole)
            {
                builder.AppendLine(item.Value.ToString());
                

            }
            return builder.ToString();



        }



    }
}
