﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KlevelBrowser.Model
{
    class HistoryLinkedList
    {

        private LinkedList<String> history;
        private LinkedList<String> historyPoped = new LinkedList<string>();   //this one  will  just comtain the top most url from the history linkedlist.
                                                                              //creates a linked list to hold url objects


        public HistoryLinkedList()
        {
            history = new LinkedList<String>();
        }

        // add url to the top of the list
        public void addTop(string link)
        {
            history.AddFirst(link);
        }

        public void AddToLast(string link)
        {
            history.AddLast(link);
        }


        public void removeFromHistory(string link)
        {
            history.Remove(link);
        }

        //writing to a file

        public void writeURLToBackwardsNavData(string link)
        {


            string HistoryFile = @"C:\Users\kumug\Documents\Visual Studio 2015\Projects\KlevelBrowser\KlevelBrowser\KlevelBrowser\NavigationDatabaseBackWards.txt";
            StreamWriter sw = new StreamWriter(HistoryFile, true);
            sw.WriteLine(link);
            sw.Close();


        }

        //method to read  the uri file
        public LinkedList<String>  readDatabase()
        {
            string HistoryFile = @"C:\Users\kumug\Documents\Visual Studio 2015\Projects\KlevelBrowser\KlevelBrowser\KlevelBrowser\DatabaseH.txt";
            using (StreamReader sr = new StreamReader(HistoryFile))
            {


                while (sr.Peek() >= 0)
                {
                    string lineRepresentingLink = sr.ReadLine();
                    history.AddFirst(lineRepresentingLink);
                }

                return history;
            }
            //from tht string create a uri object to be stored in the linkedlist



        }

        //navigation database

        public LinkedList<String> readDatabasenav()
        {
            string HistoryFile = @"C:\Users\kumug\Documents\Visual Studio 2015\Projects\KlevelBrowser\KlevelBrowser\KlevelBrowser\NavigationDatabase1.txt";
            using (StreamReader sr = new StreamReader(HistoryFile))
            {


                while (sr.Peek() >= 0)
                {
                    string lineRepresentingLink = sr.ReadLine();
                    history.AddFirst(lineRepresentingLink);
                }

                return history;
            }
            //from tht string create a uri object to be stored in the linkedlist



        }

        public LinkedList<String> readDatabasenavBackwards()
        {
            string HistoryFile = @"C:\Users\kumug\Documents\Visual Studio 2015\Projects\KlevelBrowser\KlevelBrowser\KlevelBrowser\NavigationDatabaseBackWards.txt";
            using (StreamReader sr = new StreamReader(HistoryFile))
            {


                while (sr.Peek() >= 0)
                {
                    string lineRepresentingLink = sr.ReadLine();
                    historyPoped.AddFirst(lineRepresentingLink);
                }

                return historyPoped;
            }
            //from tht string create a uri object to be stored in the linkedlist



        }



        //method to pupolate the history

        public HistoryLinkedList populate()
        {
            HistoryLinkedList HLL = new HistoryLinkedList();
            HLL.readDatabase();
            return HLL;
        }


        public String getFirstNode()
        {
            string first = history.First.Value;
            return first;
        }

        public  string findNextValue(string url)
        {
            return history.Find(url).Next.Value;
        }

        public void removeUrl(string url)
        {
            history.Remove(url);
        }

        public void makeAcopy()
        {

            string pathFrom = @"C:\Users\kumug\Documents\Visual Studio 2015\Projects\KlevelBrowser\KlevelBrowser\KlevelBrowser\DatabaseH.txt";
            string pathTo = @"C:\Users\kumug\Documents\Visual Studio 2015\Projects\KlevelBrowser\KlevelBrowser\KlevelBrowser\NavigationDatabase1.txt";
            string pathToBackwards = @"C:\Users\kumug\Documents\Visual Studio 2015\Projects\KlevelBrowser\KlevelBrowser\KlevelBrowser\NavigationDatabaseBackWards.txt";

            
            File.Copy(pathFrom, pathTo,true);
           // File.Copy(pathFrom, pathToBackwards, true);

        }

        //read contents of the linkedList
        public string getHistoryData()
        {
            StringBuilder builder = new StringBuilder();
           LinkedList<String> list= readDatabase();


            foreach (string str in list)
            {
                builder.AppendLine(str);
            }
            return builder.ToString();

        }


        #region  Favourites methods
        public LinkedList<String> readDatabaseFavs()
        {
            string HistoryFile = @"C:\Users\kumug\Documents\Visual Studio 2015\Projects\KlevelBrowser\KlevelBrowser\KlevelBrowser\FavouritesDatabase.txt";
            using (StreamReader sr = new StreamReader(HistoryFile))
            {


                while (sr.Peek() >= 0)
                {
                    string lineRepresentingLink = sr.ReadLine();
                    // Create a new LinkedListNode of type String and add it to the linkedList
                    LinkedListNode<String> lln = new LinkedListNode<String>(lineRepresentingLink);  
                    history.AddFirst(lln);
                }

                return history;
            }
            //from tht string create a uri object to be stored in the linkedlist



        }
        public string getHistoryDatafavs()
        {
            StringBuilder builder = new StringBuilder();
            LinkedList<String> list = readDatabaseFavs();


            foreach (string str in list)
            {
                builder.AppendLine(str);
            }
            return builder.ToString();

        }
        #endregion



        public string getNextUrl()
        {
            

            LinkedList<String> data1 = readDatabasenav();
            string url=data1.First.Value;
            string nextUrl1 = data1.Find(url).Next.Value;
            writeURLToBackwardsNavData(url);
            string[] nextUrlModified1 = nextUrl1.Split(new string[] { "@" }, StringSplitOptions.None);
            string finalUrl1 = nextUrlModified1[0].Trim();
            data1?.Remove(url);
            string path = @"C:\Users\kumug\Documents\Visual Studio 2015\Projects\KlevelBrowser\KlevelBrowser\KlevelBrowser\NavigationDatabase1.txt";
            var lines = System.IO.File.ReadAllLines(path);
            System.IO.File.WriteAllLines(path, lines.Take(lines.Length - 1).ToArray());
            return finalUrl1;
            
        }

        public string previousURL()
        {
            LinkedList<String> data1= readDatabasenavBackwards();
            string nextUrl1 = data1?.First.Value;
            string[] nextUrlModified1 = nextUrl1.Split(new string[] { "@" }, StringSplitOptions.None);
            string finalUrl1 = nextUrlModified1[0].Trim();
            data1?.Remove(nextUrl1);
            string path = @"C:\Users\kumug\Documents\Visual Studio 2015\Projects\KlevelBrowser\KlevelBrowser\KlevelBrowser\NavigationDatabaseBackWards.txt";
            var lines = System.IO.File.ReadAllLines(path);
            System.IO.File.WriteAllLines(path, lines.Take(lines.Length - 1).ToArray());
            return finalUrl1;
            
        }

    }
}
