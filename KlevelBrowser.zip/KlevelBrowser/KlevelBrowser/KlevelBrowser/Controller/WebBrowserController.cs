﻿using KlevelBrowser.Model;
using KlevelBrowser.View;
using Model;
using System;
using System.Diagnostics;
using System.Media;
using System.Windows.Forms;

namespace KlevelBrowser.Controller
{

    class WebBrowserController
    {
        #region fields
        private Browser browser;
        private MainPage topPage;
        private ViewHTML resultsPage = new ViewHTML();
        private viewHistory historyList = new viewHistory();
        private HistoryLinkedList historyLog = new HistoryLinkedList();
        string name;    // i need this as a class variable to avoid nullpointer exception
        //string results;
        string url;

        #endregion

        public WebBrowserController(Browser browser, MainPage topPage, ViewHTML resultsPage)
        {
            this.browser = browser;
            this.topPage = topPage;
            this.resultsPage = resultsPage;

        }

        public WebBrowserController(MainPage topPage)
        {
            this.topPage = topPage;


        }

        public WebBrowserController(ViewHTML resultsPage)
        {
            this.resultsPage = resultsPage;


        }

       
        


        public void startupView()
        {
            Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainPage());
        }

      

        public async void updateviewhtml()
        {
            browser = new Browser();
            url=topPage.geturlInput();
            //this will write the url input to the the textfile that i use as a databse
            System.DateTime newDate1 = DateTime.Now;
            string urlData = url + "@"+ newDate1.ToString();
            browser.writeURLToHistorfile(urlData);
            historyLog.makeAcopy();
            topPage.statrTimer1();
            var watch = Stopwatch.StartNew();
            
            string data = await browser?.geth(url);
            watch.Stop();
            resultsPage.Show();
            resultsPage.getrichTextbo1().Text = data;


            //update the name of the page

            name = browser.getBetween(data, "<title>", "</title>");
            resultsPage.Text = name;
            resultsPage.displayUrlTextbox().Text = url;

            //history
            //historyLog.CreateAhistoryObject(url, name);

            //results = historyLog.returnContents();
            //historyList.getRichTextB().Text = results;
            //this.historyList.Show();
            //this.historyList.WindowState = FormWindowState.Minimized;
        }

        public async void updateviewhtml( string URL)
        {
            browser = new Browser();
            //url = topPage.geturlInput();
            //this will write the url input to the the textfile that i use as a databse
            System.DateTime newDate1 = DateTime.Now;
            string urlData = URL + newDate1.ToString();
            browser.writeURLToHistorfile(urlData);
            //make copy for navigation
            



            string data = await browser?.geth(URL);
            
            resultsPage.Show();
            resultsPage.getrichTextbo1().Text = data;


            //update the name of the page

            name = browser.getBetween(data, "<title>", "</title>");
            resultsPage.Text = name;
            resultsPage.displayUrlTextbox().Text = url;

            //history
            //historyLog.CreateAhistoryObject(url, name);

            //results = historyLog.returnContents();
            //historyList.getRichTextB().Text = results;
            //this.historyList.Show();
            //this.historyList.WindowState = FormWindowState.Minimized;
        }

        public  void updatePlusviewHisroty()
        {
            

            string data=historyLog.getHistoryData();
            this.historyList.Show();
            
            
            historyList.getRichTextB().Text = data;
           

        }


        public void deleteHistory()
        {
            browser = new Browser();
            browser.clearHistory();
            string message = "History Database Cleared";
            string title = "Powered by @klevelThinking";
            SystemSounds.Asterisk.Play();
            MessageBox.Show(message, title);
        }

        //might need to rename the method

        public void addtohistory()
        {
            browser = new Browser();
           string fav= resultsPage.geturlInputFromViewPageHTML();
            browser.writeURLToHistorfavouriets(fav);
            string message = "Favourites Database updated";
            string title = "Powered by @klevelThinking";
            SystemSounds.Asterisk.Play();
            MessageBox.Show(message, title);
        }


        public void viewFavs()
        {
            string data = historyLog.getHistoryDatafavs();
            historyList.Text = "Favourites Sites   @powered by k-level-thinking";
            this.historyList.Show();


            historyList.getRichTextB().Text = data;


        }

        public void NextUrl()
        {

           string nextURL= historyLog.getNextUrl();
           updateviewhtml(nextURL);


        }

        public void prevUrl()
        {

            string nextURL = historyLog.previousURL();
            updateviewhtml(nextURL);


        }


    }          
}
