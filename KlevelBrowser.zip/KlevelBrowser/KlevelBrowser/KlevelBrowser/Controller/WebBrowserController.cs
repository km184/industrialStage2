﻿using KlevelBrowser.Model;
using KlevelBrowser.View;
using Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Media;
using System.Text;
using System.Windows.Forms;

namespace KlevelBrowser.Controller
{

    class WebBrowserController
    {
        #region fields
        private Browser browser;
        private MainPage topPage;
        private ViewHTML resultsPage = new ViewHTML();
        private viewHistory historyList = new viewHistory();
        private Favourites favViewForm;    //needs to change
        private favourites viewf = new favourites();
        private HistoryLinkedList historyLog = new HistoryLinkedList();
        string name;    // i need this as a class variable to avoid nullpointer exception
        //string results;
        string url;

        #endregion

        public WebBrowserController(Browser browser, MainPage topPage, ViewHTML resultsPage)
        {
            this.browser = browser;
            this.topPage = topPage;
            this.resultsPage = resultsPage;

        }

        public WebBrowserController(MainPage topPage)
        {
            this.topPage = topPage;


        }

        public WebBrowserController(favourites viewf)
        {
            this.viewf = viewf;


        }

        public WebBrowserController(ViewHTML resultsPage)
        {
            this.resultsPage = resultsPage;


        }

       
        


        public void startupView()
        {
            Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainPage());
        }

      

        public async void updateviewhtml()
        {
            browser = new Browser();
            url=topPage.geturlInput();
            //this will write the url input to the the textfile that i use as a databse
            System.DateTime newDate1 = DateTime.Now;
            string urlData = url + "@"+ newDate1.ToString();
            browser.writeURLToHistorfile(urlData);
            historyLog.makeAcopy();
            
            var watch = Stopwatch.StartNew();
            
            string data = await browser?.geth(url);
            watch.Stop();
            resultsPage.Show();
            resultsPage.getrichTextbo1().Text = data;


            //update the name of the page

            name = browser.getBetween(data, "<title>", "</title>");
            resultsPage.Text = name;
            resultsPage.displayUrlTextbox().Text = url;

            //history
            //historyLog.CreateAhistoryObject(url, name);

            //results = historyLog.returnContents();
            //historyList.getRichTextB().Text = results;
            //this.historyList.Show();
            //this.historyList.WindowState = FormWindowState.Minimized;
        }

        public async void updateviewhtml( string URL)
        {
            browser = new Browser();
            //url = topPage.geturlInput();
            //this will write the url input to the the textfile that i use as a databse
            System.DateTime newDate1 = DateTime.Now;
            string urlData = URL + newDate1.ToString();
            browser.writeURLToHistorfile(urlData);
            //make copy for navigation
            



            string data = await browser?.geth(URL);
            
            resultsPage.Show();
            resultsPage.getrichTextbo1().Text = data;


            //update the name of the page

            name = browser.getBetween(data, "<title>", "</title>");
            resultsPage.Text = name;
            resultsPage.displayUrlTextbox().Text = url;

            //history
            //historyLog.CreateAhistoryObject(url, name);

            //results = historyLog.returnContents();
            //historyList.getRichTextB().Text = results;
            //this.historyList.Show();
            //this.historyList.WindowState = FormWindowState.Minimized;
        }

        public  void updatePlusviewHisroty()
        {
            

            string data=historyLog.getHistoryData();
            this.historyList.Show();
            
            
            historyList.getRichTextB().Text = data;
           

        }


        public void deleteHistory()
        {
            browser = new Browser();
            browser.clearHistory();
            string message = "History Database Cleared";
            string title = "Powered by @klevelThinking";
            SystemSounds.Asterisk.Play();
            MessageBox.Show(message, title);
        }

        //might need to rename the method

        public async void addtohistory()
        {
            
            browser = new Browser();
            
            string fav= resultsPage.geturlInputFromViewPageHTML();
            string data = await browser?.geth(fav);
            name = browser.getBetween(data, "<title>", "</title>");
            string nameAndURL=fav+"@" + name;
            browser.writeURLToHistorfavouriets(nameAndURL);
            string message =$"{name} was added to your favourites successfully!";
            string title = "Powered by @klevelThinking";
            SystemSounds.Asterisk.Play();
            MessageBox.Show(message, title);
        }


        //public  void viewFavs()
        //{

        //    //string[] nextUrlModified1 = nextUrl1.Split(new string[] { "@" }, StringSplitOptions.None);
        //    //string finalUrl1 = nextUrlModified1[0].Trim();

        //    Hashtable data = historyLog.getHistoryDatafavs();  //this returns an array of the strings  
        //    StringBuilder builder = new StringBuilder();
        //    var links = new List<LinkLabel.Link>();
        //    historyList.Text = "Favourites Sites   @powered by k-level-thinking";
        //        this.historyList.Show();
        //       // historyList.HideRichTextBox();
        //   foreach(DictionaryEntry entry in data)
        //    {
        //        string name = entry.Key.ToString();
        //        Uri url = new Uri(entry.Value.ToString());
        //        builder.AppendLine($"{name}  {url}");
        //        historyList.getLinkLabel().Links.Add(url);
        //        // = builder.ToString();
        //    }
        //    historyList.getLinkLabel().Text = builder.ToString();
        //   //historyList.getRichTextB().Text = builder.ToString();


        //}

        //public void viewFavs()
        //{
        //    Hashtable data = historyLog.getHistoryDatafavs();
        //    var builder = new StringBuilder();
        //    var links = new List<LinkLabel.Link>();
        //    foreach (DictionaryEntry entry in data)
        //    {
        //        //string name = entry.Key.ToString();
        //      string website= entry.Value.ToString();
        //        //builder.AppendLine($"{name}  {url}");
        //        //historyList.getLinkLabel().Links.Add(url);
        //        // = builder.ToString();
        //        builder.AppendLine();
        //        links.Add(new LinkLabel.Link(builder.Length, website.Length, website));
        //    }
        //    foreach (var link in links)
        //    {
        //        historyList.getLinkLabel().Links.Add(link);
        //    }
        //    historyList.getLinkLabel().AutoSize = true;
        //}
        public void viewFavs()
        {
            Hashtable data = historyLog.getHistoryDatafavs();

            

               foreach (DictionaryEntry entry in data)
            {
                string name = entry.Key.ToString();
                string website = entry.Value.ToString();
                favViewForm = new Favourites(name, website);
                viewf.getfavBingSource().Add(favViewForm);
                
            }

            viewf.Show();
        }


        public async void loadFav()
        {
            browser = new Browser();
            
            string url= viewf.getContentsOfCell();
            string data = await browser?.geth(url);

            resultsPage.Show();
            resultsPage.getrichTextbo1().Text = data;
        }



        public void NextUrl()
        {

           string nextURL= historyLog.getNextUrl();
           updateviewhtml(nextURL);


        }

        public void prevUrl()
        {

            string nextURL = historyLog.previousURL();
            updateviewhtml(nextURL);


        }


    }          
}
